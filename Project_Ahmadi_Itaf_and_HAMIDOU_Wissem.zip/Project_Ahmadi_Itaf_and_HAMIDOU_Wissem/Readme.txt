@Author : Hamidou Wissem & Ahmadi Itaf

The file code contains all the functions that we coded in this project.

* functions.py : python file that contains the functions : objective, objective_P and objective_Q
* Part1_Als.ipynb : notebook file that contains all the functions, algorithms and interpretations related to the ALS method
* Part2_SGD.ipynb : notebook file that contains all the functions, algorithms and interpretations related to the SGD method
* u.data : mini dataset file (size 1M) downloaded from MovieLens website https://grouplens.org/datasets/movielens/
* ml_20m : dataset of 20M (size 190 MB) downloaded from MovieLens website https://grouplens.org/datasets/movielens/
* ratings.csv : csv file that contains userId, movieId, ratings and timestamps

* P.csv and Q.csv are csv file containing the output matrices resulting from the decomposition using SGD approach


#### Requirements to run the code 
Anaconda 3 or +
Spark 2.2